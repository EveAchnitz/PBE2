package br.com.joalheriajoiasjoia.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository; 

import br.com.joalheriajoiasjoia.app.entities.OrnamentoProduto;

public interface OrnamentoProdutoRepository  extends JpaRepository<OrnamentoProduto, Long>{

}
